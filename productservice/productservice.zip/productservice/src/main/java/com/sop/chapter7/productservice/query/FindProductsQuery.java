package com.sop.chapter7.productservice.query;

public class FindProductsQuery {
}
